package com.zybooks.atm;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ATM {
    private double balance;
    private final String LOG_FILE = "transactions.log";
    private final String cardNumber;
    private final String pin;

    public ATM(double initialBalance, String cardNumber, String pin) {
        balance = initialBalance;
        this.cardNumber = cardNumber;
        this.pin = pin;
        System.out.println("Welcome to the ATM!");
    }

    public void checkBalance() {
        System.out.println("Your balance is: $" + balance);
        logTransaction("Balance check", 0.0);
    }

    public void withdraw(double amount, String cardNumber, String pin) {
        if (!this.cardNumber.equals(cardNumber) || !this.pin.equals(pin)) {
            System.out.println("Invalid card number or PIN.");
            logTransaction("Withdrawal failed - invalid card or PIN", amount);
            return;
        }

        if (amount % 20 != 0) {
            System.out.println("Amount must be in multiples of $20.");
            logTransaction("Withdrawal failed - invalid amount", amount);
            return;
        }

        if (amount > balance) {
            System.out.println("Insufficient funds.");
            logTransaction("Withdrawal failed - insufficient funds", amount);
        } else {
            balance -= amount;
            System.out.println("Withdrawal successful. Your new balance is: $" + balance);
            logTransaction("Withdrawal", amount);
        }
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit successful. Your new balance is: $" + balance);
        logTransaction("Deposit", amount);
    }

    private void logTransaction(String type, double amount) {
        try {
            FileWriter writer = new FileWriter(LOG_FILE, true);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            String timestamp = formatter.format(date);
            writer.write(timestamp + " - " + type + " - $" + amount + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println("Failed to log transaction: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        ATM myATM = new ATM(1000, "1234 5678 9012 3456", "1234");
        myATM.checkBalance();
        myATM.withdraw(40, "1234 5678 9012 3456", "1234");
        myATM.deposit(100);
        myATM.checkBalance();
    }
}
