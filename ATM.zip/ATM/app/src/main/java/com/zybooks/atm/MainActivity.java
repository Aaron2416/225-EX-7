package com.zybooks.atm;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private double balance = 1000.0;
    private EditText amountEditText;
    private EditText cardNumberEditText;
    private EditText pinEditText;
    private TextView balanceTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amountEditText = findViewById(R.id.amount_edittext);
        cardNumberEditText = findViewById(R.id.card_number_edittext);
        pinEditText = findViewById(R.id.pinEditText);
        balanceTextView = findViewById(R.id.balance_textview);

        Button checkBalanceButton = findViewById(R.id.check_balance_button);
        checkBalanceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Current balance: $" + balance, Toast.LENGTH_SHORT).show();
            }
        });

        Button withdrawButton = findViewById(R.id.withdraw_button);
        withdrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String amountString = amountEditText.getText().toString();
                String cardNumberString = cardNumberEditText.getText().toString();
                String pinString = pinEditText.getText().toString();

                if (amountString.isEmpty() || cardNumberString.isEmpty() || pinString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    double amount = Double.parseDouble(amountString);
                    if (amount > balance) {
                        Toast.makeText(MainActivity.this, "Insufficient funds", Toast.LENGTH_SHORT).show();
                    } else {
                        balance -= amount;
                        Toast.makeText(MainActivity.this, "Withdrawal successful", Toast.LENGTH_SHORT).show();
                        balanceTextView.setText("Current balance: $" + balance);
                    }
                }
            }
        });

        Button depositButton = findViewById(R.id.deposit_button);
        depositButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String amountString = amountEditText.getText().toString();
                String cardNumberString = cardNumberEditText.getText().toString();
                String pinString = pinEditText.getText().toString();

                if (amountString.isEmpty() || cardNumberString.isEmpty() || pinString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    double amount = Double.parseDouble(amountString);
                    balance += amount;
                    Toast.makeText(MainActivity.this, "Deposit successful", Toast.LENGTH_SHORT).show();
                    balanceTextView.setText("Current balance: $" + balance);
                }
            }
        });
    }
}
